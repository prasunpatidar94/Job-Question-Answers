package com.pp.sun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidationAndExceptionHandlingWithActuatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValidationAndExceptionHandlingWithActuatorApplication.class, args);
	}

}
